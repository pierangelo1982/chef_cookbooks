name 'production'
description 'Where we run production code'

cookbook 'mysql', '= 8.5.1'
cookbook 'lamp', '= 0.1.9'
