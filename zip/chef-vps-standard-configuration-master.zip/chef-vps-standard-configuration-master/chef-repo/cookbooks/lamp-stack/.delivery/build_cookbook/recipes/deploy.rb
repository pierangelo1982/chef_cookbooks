#
# Cookbook:: build_cookbook
# Recipe:: deploy
#
# Copyright:: 2018, The Authors, All Rights Reserved.
include_recipe 'delivery-truck::deploy'
