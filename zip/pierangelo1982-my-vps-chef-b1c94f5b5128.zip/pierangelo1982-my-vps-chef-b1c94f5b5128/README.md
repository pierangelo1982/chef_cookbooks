The chef-repo
===============

VPS OVH
-------------------
PARAMETRI DI ACCESSO:
Indirizzo IPv4 del VPS: 54.37.153.249
Indirizzo IPv6 del VPS: 2001:41d0:0401:3200:0000:0000:0000:015c

Nome del VPS: vps502830.ovh.net

Sul VPS è stato configurato questo account amministratore:
Nome utente: root
Password: BNIWy9LX

Cookbooks
---------
A cookbook is the fundamental unit of configuration and policy distribution. A sample cookbook can be found in `cookbooks/starter`. After making changes to any cookbook, you must upload it to the Chef server using knife:

    $ knife upload cookbooks/starter

For more information about cookbooks, see the example files in the `starter` cookbook.

Roles
-----
Roles provide logical grouping of cookbooks and other roles. A sample role can be found at `roles/starter.rb`.

Getting Started
-------------------------
Now that you have the chef-repo ready to go, check out [Learn Chef](https://learn.chef.io/) to proceed with your workstation setup. If you have any questions about Chef you can always ask [our support team](https://www.chef.io/support/) for a helping hand.
